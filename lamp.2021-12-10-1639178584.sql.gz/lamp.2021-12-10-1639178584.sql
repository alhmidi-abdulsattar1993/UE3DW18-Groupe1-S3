-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tl_liens`
--

DROP TABLE IF EXISTS `tl_liens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_liens` (
  `lien_id` int(11) NOT NULL AUTO_INCREMENT,
  `lien_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lien_titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lien_desc` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`lien_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_liens`
--

LOCK TABLES `tl_liens` WRITE;
/*!40000 ALTER TABLE `tl_liens` DISABLE KEYS */;
INSERT INTO `tl_liens` VALUES (2,'https://duckduckgo.com/','Duck Duck Go','Le moteur de recherche qui ne trace pas ses utilisateurs.',1),(3,'https://www.hostinger.fr/tutoriels/cest-quoi-bootstrap/','C’est quoi Bootstrap','For the first time ever, Bootstrap has its own open source SVG icon library,',1),(4,'https://neuralink.com/','neuralink','Developing ultra high bandwidth brain-machine interfaces to connect humans and computers',1),(5,'https://www.histoiredor.com/fr_FR','Histoire d\'or','le premier bijoutier de France Découvrez plus de 3000 bijoux',1),(6,'https://angular.io/docs','Angular','Angular is a platform for building mobile and desktop web applications.',1),(7,'https://www.01net.com/telecharger/windows/Programmation/java/','JAVA','Java SE vous aide à développer et à déployer des applications Java sur des postes de travail et des serveurs',1),(8,'https://www.youtube.com/user/NothingToxicExtreme','NothingToxicExtreme','Welcome to NothingToxicExtreme.... the channel with Extreme stunts, fights and bizzar events',1),(9,'https://www.futura-sciences.com/tech/technologie/actualites/','Futura','Les Actualités Technologie, par Futura Tech, le magazine des technologies de demain.',1),(10,'https://fr.wikipedia.org/wiki/Techniques_de_pointe','Techniques de pointe','Les techniques de pointe1, hautes technologies2\'3,4 ou, abusivement5 technologies de pointe, aussi connues sous l\'anglicisme high-tech (pour high technology), sont des techniques considérées comme les plus avancées à une époque donnée',1),(11,'https://fr.wikipedia.org/wiki/Syst%C3%A8me_de_traitement_de_l%27information','Système de traitement de l\'information','Un système de traitement de l\'information est un système constitué d\'un ensemble de composants (mécaniques, électroniques, chimiques, photoniques ou biologiques) permettant de traiter automatiquement des informations.',1),(12,'https://fr.wikipedia.org/wiki/Num%C3%A9rique','Numérique','On dit numérique une information qui se présente sous forme de nombres associés à une indication de la grandeur physique à laquelle ils s\'appliquent, permettant les calculs,',1),(13,'https://www.lumni.fr/college/troisieme/technologie','Lumni','présente sous forme de nombres associés s s\'appliquent, permettant les calculs,',1),(14,'http://www.agoogleaday.com/#date=2012-01-04','Google','google day feel lucky',1),(15,'https://jquery.com/','jQuery','jQuery is a fast, small, and feature-rich JavaScript library.',1),(16,'https://jqueryui.com/','jQuery UI','jQuery UI is a curated set of user interface interactions, effects, widgets, and themes built on top of the jQuery JavaScript Library.',1),(17,'https://jquerymobile.com/','jQuery Mobile','jQuery Mobile is a HTML5-based user interface system designed to make responsive web sites and apps that are accessible on all smartphone',1);
/*!40000 ALTER TABLE `tl_liens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_tags`
--

DROP TABLE IF EXISTS `tl_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_tags` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_tags`
--

LOCK TABLES `tl_tags` WRITE;
/*!40000 ALTER TABLE `tl_tags` DISABLE KEYS */;
INSERT INTO `tl_tags` VALUES (1,'fac'),(2,'vieprivee'),(3,'opensource'),(4,'apprendre'),(5,'no'),(6,'tags'),(7,'open'),(8,'source');
/*!40000 ALTER TABLE `tl_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_tags_liens`
--

DROP TABLE IF EXISTS `tl_tags_liens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_tags_liens` (
  `tag_id` int(11) NOT NULL,
  `lien_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_tags_liens`
--

LOCK TABLES `tl_tags_liens` WRITE;
/*!40000 ALTER TABLE `tl_tags_liens` DISABLE KEYS */;
INSERT INTO `tl_tags_liens` VALUES (1,1),(2,2),(3,2),(3,3),(5,4),(6,4),(7,3),(8,3),(7,4),(8,4),(5,5),(6,5),(5,6),(6,6),(7,7),(8,7),(7,8),(8,8),(7,9),(8,9),(7,10),(8,10),(7,11),(8,11),(7,12),(8,12),(7,13),(8,13),(7,14),(8,14),(7,15),(8,15),(7,16),(8,16),(5,17),(6,17);
/*!40000 ALTER TABLE `tl_tags_liens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_users`
--

DROP TABLE IF EXISTS `tl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_users` (
  `usr_id` int(11) NOT NULL AUTO_INCREMENT,
  `usr_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `usr_password` varchar(88) COLLATE utf8_unicode_ci NOT NULL,
  `usr_salt` varchar(23) COLLATE utf8_unicode_ci NOT NULL,
  `usr_role` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ROLE_ADMIN',
  PRIMARY KEY (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_users`
--

LOCK TABLES `tl_users` WRITE;
/*!40000 ALTER TABLE `tl_users` DISABLE KEYS */;
INSERT INTO `tl_users` VALUES (1,'admin','aoUz0skAjbs2SoyiPsoYxTHiYZFbyPXyHWc4uD9eKkXZwA+YDklaCM63/xrP+GVJ9FFFhTgRu4f+UaV5lJ15Jw==','b6d101785059c7abcd666e3','ROLE_ADMIN');
/*!40000 ALTER TABLE `tl_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-10 23:23:04
